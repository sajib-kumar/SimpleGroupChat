
package client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) throws IOException {

        Socket clientSocket = new Socket("localhost", 6789);

        DataInputStream dis = new DataInputStream(clientSocket.getInputStream());
        DataOutputStream dos = new DataOutputStream(clientSocket.getOutputStream());
        BufferedReader br = new BufferedReader(new InputStreamReader(dis));

        String u = br.readLine();
        System.out.println(u);

        Scanner sc = new Scanner(System.in);
        String username = sc.nextLine();

        dos.writeBytes(username + '\n');

        ClientReader clientReader = new ClientReader(dis, dos, br);
        clientReader.start();
        ClientWritter clientWritter = new ClientWritter(dis, dos, br);

        clientWritter.start();

    }
}
