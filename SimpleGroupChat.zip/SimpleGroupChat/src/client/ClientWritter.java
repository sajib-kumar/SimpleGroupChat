/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Joy
 */
public class ClientWritter extends Thread {

    DataInputStream dis;
    DataOutputStream dos;
    BufferedReader br;

    public ClientWritter(DataInputStream dis, DataOutputStream dos, BufferedReader br) {
        this.dis = dis;
        this.dos = dos;
        this.br = br;
    }

    public void run() {

        while (true) {
            try {
                
                
              
                     Scanner scanner = new Scanner(System.in);
                     String msg = scanner.nextLine();
                     dos.writeBytes(msg + '\n');
                     
                 
              
            } catch (IOException ex) {
                Logger.getLogger(ClientWritter.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

}
