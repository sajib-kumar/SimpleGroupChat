package server;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server {

    static ArrayList<ClientInfo> clients = new ArrayList<ClientInfo>();
    static int count=0; 
    public static void main(String[] args) throws IOException {

        ServerSocket welcomeSocket = new ServerSocket(6789);
        int id = 0;

        while (true) {
            Socket connectionSocket = null;

            connectionSocket = welcomeSocket.accept();

            System.out.println("A new client has joined with socket : " + connectionSocket);

            DataInputStream dis = new DataInputStream(connectionSocket.getInputStream());
            DataOutputStream dos = new DataOutputStream(connectionSocket.getOutputStream());

            ClientInfo ci = new ClientInfo(connectionSocket, dis, dos, ++id);
            ClientHandler clientHandler = new ClientHandler(ci, clients);
            System.out.println((++count)+ " Person connected...");
            clientHandler.start();

        }

    }
    
    public static void left(){
        System.out.println("People Remaining: "+(--count));
    }

}
