/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;

/**
 *
 * @author Joy
 */
public class ClientInfo {

    DataInputStream dis;
    DataOutputStream dos;
    Socket s;
    int clientId;
    String name;


    ClientInfo(Socket connectionSocket, DataInputStream dis, DataOutputStream dos, int i) {
         s = connectionSocket;
        this.dis = dis;
        this.dos = dos;
        clientId = i;
 
    }

}
