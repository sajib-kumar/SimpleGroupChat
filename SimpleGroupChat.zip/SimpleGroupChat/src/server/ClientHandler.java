package server;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ClientHandler extends Thread {

    ClientInfo ci;
    ArrayList<ClientInfo> clients;

    ClientHandler(ClientInfo ci, ArrayList<ClientInfo> clients) {
        this.ci = ci;
        this.clients = clients;
    }

    @Override
    public void run() {
         String n =null;
        try {
            String msg = "Enter Your UserName: ";
            ci.dos.writeBytes(msg + '\n');

            BufferedReader br = new BufferedReader(new InputStreamReader(ci.dis));
             n = br.readLine();
            ci.name = n;
            clients.add(ci);

            for (int i = 0; i < clients.size() - 1; i++) {
                ClientInfo cl = clients.get(i);
                cl.dos.writeBytes(n + " has just joined" + '\n');

            }

            while (true) {
                String sentenceFromClient = br.readLine();

                String s = n + ": " + sentenceFromClient;

                for (ClientInfo ci : clients) {
                   
                        ci.dos.writeBytes(s + '\n');
                    
                }

            }

        } catch (IOException ex) {
            for(ClientInfo x: clients){
                if(!x.name.equals(n)){
                    try {
                        x.dos.writeBytes(n+" Just left"+'\n');
                    } catch (IOException ex1) {
                    }
                }
                    
                
            }
            
            Server.left();
            
            
        }

    }
}

